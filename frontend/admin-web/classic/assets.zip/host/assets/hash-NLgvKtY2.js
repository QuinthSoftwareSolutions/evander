function n(r=window.location.hash){const a=r.replace(/^#/,"").trim().split("?")[1]??"";return new URLSearchParams(a)}export{n as r};
