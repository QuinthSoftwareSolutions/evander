// shared/engine.ts
var BrowserEngine = class {
  constructor(send2, state, emit) {
    this.send = send2;
    this.state = state;
    this.emit = emit;
  }
  observation = "";
  refs = /* @__PURE__ */ new Map();
  epoch = 0;
  update(state) {
    this.state = state;
  }
  navigate() {
    this.epoch += 1;
    this.observation = "";
    this.refs.clear();
  }
  async location() {
    const tree = await this.send("Page.getFrameTree");
    return tree.frameTree.frame.url;
  }
  guard(command, actor, epoch) {
    if (Date.now() / 1e3 >= this.state.expires_at) throw new Error("session_expired");
    if (command.generation !== this.state.control_generation) throw new Error("stale_control");
    if (!["observe", "highlight"].includes(command.action) && this.state.controller !== actor)
      throw new Error("control_required");
    if (epoch !== void 0 && epoch !== this.epoch) throw new Error("stale_observation");
  }
  async execute(command, actor) {
    const epoch = this.epoch;
    const fence = async () => {
      this.guard(command, actor, epoch);
      const current = await this.location();
      this.guard(command, actor, epoch);
      if (!this.state.allowed_origins.includes(new URL(current).origin)) throw new Error("origin_denied");
      return current;
    };
    const input = async (method, params = {}) => {
      await fence();
      this.guard(command, actor, epoch);
      return this.send(method, params);
    };
    const press = async (key, text, code, keyCode) => {
      const identity = {
        key,
        ...code ? { code } : {},
        ...keyCode ? { windowsVirtualKeyCode: keyCode } : {}
      };
      await input("Input.dispatchKeyEvent", {
        type: "keyDown",
        ...identity,
        ...text !== void 0 ? { text, unmodifiedText: text } : {}
      });
      await input("Input.dispatchKeyEvent", { type: "keyUp", ...identity });
    };
    const url = await fence();
    if (command.action === "observe") {
      const before = this.epoch;
      const { nodes } = await this.send("Accessibility.getFullAXTree");
      this.refs.clear();
      const elements = [];
      const roles = /* @__PURE__ */ new Set([
        "button",
        "link",
        "textbox",
        "combobox",
        "checkbox",
        "radio",
        "tab",
        "menuitem",
        "option",
        "heading",
        "dialog",
        "alert",
        "gridcell",
        "row"
      ]);
      for (const node of nodes ?? []) {
        if (elements.length >= 600) break;
        const role = node.role?.value;
        if (node.ignored || !node.backendDOMNodeId || !roles.has(role)) continue;
        const ref = "node-" + node.backendDOMNodeId;
        this.refs.set(ref, node.backendDOMNodeId);
        elements.push({ ref, role, name: String(node.name?.value ?? "").slice(0, 400) });
      }
      let screenshot;
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          screenshot = await this.send("Page.captureScreenshot", {
            format: "jpeg",
            quality: 65,
            captureBeyondViewport: false
          });
          break;
        } catch (error) {
          if (attempt === 2) throw error;
          await new Promise((resolve) => setTimeout(resolve, 75));
        }
      }
      await fence();
      if (before !== this.epoch) throw new Error("stale_observation");
      this.observation = crypto.randomUUID();
      return {
        observation_id: this.observation,
        page_epoch: String(this.epoch),
        url,
        elements,
        image: screenshot.data,
        mime_type: "image/jpeg"
      };
    }
    if (!["navigate", "reload"].includes(command.action) && command.observation_id !== this.observation)
      throw new Error("stale_observation");
    if (command.action === "navigate") {
      if (!this.state.allowed_origins.includes(new URL(command.url).origin)) throw new Error("origin_denied");
      await input("Page.navigate", { url: command.url });
      this.navigate();
      return { success: true };
    }
    if (command.action === "reload") {
      await input("Page.reload");
      this.navigate();
      return { success: true };
    }
    let x = command.x, y = command.y;
    if (command.ref && ["click", "hover", "highlight"].includes(command.action)) {
      const backendNodeId = this.refs.get(command.ref);
      if (!backendNodeId) throw new Error("stale_observation");
      if (command.action !== "highlight") {
        await input("DOM.scrollIntoViewIfNeeded", { backendNodeId });
        await fence();
      }
      const { model } = await this.send("DOM.getBoxModel", { backendNodeId });
      x = (model.content[0] + model.content[4]) / 2;
      y = (model.content[1] + model.content[5]) / 2;
    }
    const metrics = await this.send("Page.getLayoutMetrics");
    const viewport = metrics.cssVisualViewport ?? metrics.visualViewport;
    if (["click", "hover", "highlight"].includes(command.action)) {
      if (!Number.isFinite(x) || !Number.isFinite(y) || x < 0 || y < 0 || x > viewport.clientWidth || y > viewport.clientHeight) throw new Error("invalid_coordinates");
      await fence();
      this.emit({ kind: "pointer", x, y, action: command.action });
      if (command.action === "highlight") return { success: true };
      this.guard(command, actor);
      await input("Input.dispatchMouseEvent", { type: "mouseMoved", x, y });
      if (command.action === "click") {
        this.guard(command, actor);
        await input("Input.dispatchMouseEvent", { type: "mousePressed", x, y, button: "left", clickCount: 1 });
        await input("Input.dispatchMouseEvent", { type: "mouseReleased", x, y, button: "left", clickCount: 1 });
      }
    } else if (command.action === "fill") {
      const backendNodeId = this.refs.get(command.ref);
      if (!backendNodeId) throw new Error("stale_observation");
      await input("DOM.focus", { backendNodeId });
      this.guard(command, actor);
      await input("Input.dispatchKeyEvent", { type: "keyDown", key: "a", code: "KeyA", modifiers: 2, windowsVirtualKeyCode: 65 });
      await input("Input.dispatchKeyEvent", { type: "keyUp", key: "a", code: "KeyA", modifiers: 2, windowsVirtualKeyCode: 65 });
      this.guard(command, actor);
      await input("Input.insertText", { text: command.text ?? "" });
    } else if (command.action === "type") {
      for (const character of (command.text ?? "").replace(/\r\n/g, "\n")) {
        const newline = character === "\n" || character === "\r";
        await press(
          newline ? "Enter" : character,
          newline ? "\r" : character,
          newline ? "Enter" : character === " " ? "Space" : void 0,
          newline ? 13 : character === " " ? 32 : void 0
        );
      }
    } else if (command.action === "key") {
      const keys = {
        Enter: 13,
        Tab: 9,
        Escape: 27,
        Backspace: 8,
        Delete: 46,
        ArrowLeft: 37,
        ArrowUp: 38,
        ArrowRight: 39,
        ArrowDown: 40,
        Space: 32
      };
      const key = command.text;
      if (!keys[key]) throw new Error("unsupported_key");
      await press(
        key === "Space" ? " " : key,
        key === "Enter" ? "\r" : key === "Space" ? " " : void 0,
        key,
        keys[key]
      );
    } else if (command.action === "scroll") {
      this.guard(command, actor);
      await input("Input.dispatchMouseEvent", {
        type: "mouseWheel",
        x: x ?? 10,
        y: y ?? 10,
        deltaX: command.delta_x ?? 0,
        deltaY: command.delta_y ?? 0
      });
    } else if (command.action === "dialog") {
      this.guard(command, actor);
      await input("Page.handleJavaScriptDialog", { accept: command.accept === true });
    } else {
      throw new Error("unsupported_action");
    }
    return { success: true, url: await this.location() };
  }
};

// extension/background.ts
var connection;
var socket;
var engine;
var tabId;
var granted = false;
var retry;
var chain = Promise.resolve();
var streaming = false;
var heartbeat;
var expiry;
var deniedOrigin;
var mainFrameId;
chrome.action.onClicked.addListener(async (tab) => {
  if (!connection) tabId = tab.id;
  await chrome.sidePanel.open({ tabId: tab.id });
});
function send(message) {
  if (socket?.readyState === WebSocket.OPEN) socket.send(JSON.stringify(message));
}
async function cdp(method, params = {}) {
  if (!tabId) throw new Error("tab_closed");
  return chrome.debugger.sendCommand({ tabId }, method, params);
}
function update(state) {
  if (!connection || state.id !== connection.session.id) return;
  connection.session = { ...state, allowed_origins: [connection.approvedOrigin] };
  if (!granted) connection.session.controller = null;
  engine?.update(connection.session);
}
function pauseForOrigin(url) {
  if (!connection) return;
  let currentOrigin;
  try {
    currentOrigin = new URL(url).origin;
  } catch {
    currentOrigin = "null";
  }
  if (currentOrigin === connection.approvedOrigin) return;
  granted = false;
  update({ ...connection.session, controller: null });
  if (!deniedOrigin) send({ kind: "paused" });
  deniedOrigin = currentOrigin;
}
async function api(action, body) {
  if (!connection) throw new Error("Share a tab first");
  const response = await fetch(connection.base + "/_browser/guest/" + action, {
    method: body ? "POST" : "GET",
    headers: { "Authorization": "Bearer " + connection.host_token, ...body ? { "Content-Type": "application/json" } : {} },
    body: body ? JSON.stringify(body) : void 0,
    credentials: "omit",
    redirect: "error"
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error ?? "Support session unavailable");
  return result;
}
async function overlay(message) {
  if (!tabId) return;
  await chrome.scripting.executeScript({
    target: { tabId },
    func: (x, y) => {
      let dot = document.getElementById("__evander_agent_pointer");
      if (!dot) {
        dot = document.createElement("div");
        dot.id = "__evander_agent_pointer";
        dot.setAttribute("aria-label", "Truman pointer");
        Object.assign(dot.style, {
          position: "fixed",
          width: "18px",
          height: "18px",
          border: "3px solid #aa36ff",
          borderRadius: "50%",
          pointerEvents: "none",
          zIndex: "2147483647",
          transition: "left 120ms, top 120ms",
          boxShadow: "0 0 0 4px #aa36ff30"
        });
        document.documentElement.append(dot);
      }
      dot.style.left = String(x - 9) + "px";
      dot.style.top = String(y - 9) + "px";
    },
    args: [message.x, message.y]
  });
}
async function connectEndpoint() {
  if (!connection || !tabId || !engine) return;
  streaming = false;
  const current = connection;
  socket = new WebSocket(connection.base.replace(/^http/, "ws") + "/_browser/extension");
  socket.addEventListener("open", () => send({ kind: "authenticate", version: 1, token: current.endpoint_token }));
  socket.addEventListener("error", () => socket?.close());
  socket.addEventListener("message", (event) => {
    let message;
    try {
      message = JSON.parse(String(event.data));
    } catch {
      socket?.close();
      return;
    }
    if (message.kind === "state") {
      update(message.session);
      if (!streaming) {
        streaming = true;
        void cdp("Page.startScreencast", { format: "jpeg", quality: 65, maxWidth: 1920, maxHeight: 1080 });
        void cdp("Page.getFrameTree").then((tree) => send({ kind: "ready", url: tree.frameTree.frame.url }));
      }
    } else if (message.kind === "pause") {
      granted = false;
      update({ ...connection.session, controller: null });
    } else if (message.kind === "command") {
      chain = chain.then(async () => {
        try {
          const result = await engine.execute(message.command, message.actor);
          send({ kind: "result", id: message.command.id, result });
        } catch (error) {
          send({
            kind: "result",
            id: message.command.id,
            error: true,
            code: /^[a-z_]+$/.test(error.message) ? error.message : "browser_error"
          });
        }
      });
    }
  });
  socket.addEventListener("close", (event) => {
    if (connection !== current) return;
    if (event.code === 1008) {
      void disconnect(false);
      return;
    }
    granted = false;
    if (connection) update({ ...connection.session, controller: null });
    if (connection === current && tabId) retry = setTimeout(() => void connectEndpoint(), 3e3);
  });
  clearInterval(heartbeat);
  heartbeat = setInterval(() => send({ kind: "heartbeat" }), 2e4);
}
async function attach() {
  if (!connection || !tabId) throw new Error("Select the application tab");
  let step = "attaching Chrome to the tab";
  try {
    await chrome.debugger.attach({ tabId }, "1.3");
    step = "preparing the shared browser";
    engine = new BrowserEngine(cdp, connection.session, (message) => {
      send(message);
      void overlay(message).catch(() => {
      });
    });
    step = "enabling page access";
    await cdp("Page.enable");
    step = "reading the page frame";
    mainFrameId = (await cdp("Page.getFrameTree")).frameTree.frame.id;
    step = "enabling accessibility";
    await cdp("Accessibility.enable");
    step = "connecting to Truman";
    await connectEndpoint();
  } catch (error) {
    const reason = String(error?.message ?? error ?? "Unknown browser error").replace(/\s+/g, " ").slice(0, 400);
    throw new Error(`Browser setup failed while ${step}: ${reason}`);
  }
}
async function disconnect(close = true) {
  const previous = connection;
  if (connection) engine?.update({ ...connection.session, controller: null, control_generation: connection.session.control_generation + 1 });
  connection = void 0;
  granted = false;
  clearTimeout(retry);
  clearTimeout(expiry);
  clearInterval(heartbeat);
  socket?.close();
  engine = void 0;
  if (tabId) {
    try {
      await chrome.debugger.detach({ tabId });
    } catch {
    }
  }
  await chrome.storage.session.remove("connection");
  if (close && previous) {
    await fetch(previous.base + "/_browser/guest/close", {
      method: "POST",
      headers: { "Authorization": "Bearer " + previous.host_token, "Content-Type": "application/json" },
      body: "{}",
      credentials: "omit",
      redirect: "error"
    }).catch(() => {
    });
  }
}
chrome.debugger.onDetach.addListener((source) => {
  if (source.tabId !== tabId || !connection) return;
  granted = false;
  send({ kind: "paused" });
  connection = void 0;
  socket?.close();
  engine = void 0;
  clearTimeout(retry);
  clearInterval(heartbeat);
  void chrome.storage.session.remove("connection");
});
chrome.tabs.onRemoved.addListener((id) => {
  if (id === tabId) void disconnect();
});
chrome.debugger.onEvent.addListener(async (source, method, params) => {
  if (source.tabId !== tabId || !connection || !engine) return;
  if (method === "Page.frameNavigated" || method === "Page.navigatedWithinDocument") {
    engine.navigate();
    if (method === "Page.frameNavigated" && !params.frame.parentId) {
      mainFrameId = params.frame.id;
      pauseForOrigin(params.frame.url);
    } else if (method === "Page.navigatedWithinDocument" && params.frameId === mainFrameId) {
      pauseForOrigin(params.url);
    }
  }
  if (method !== "Page.screencastFrame") return;
  try {
    const tree = await cdp("Page.getFrameTree");
    const url = tree.frameTree.frame.url;
    if (new URL(url).origin !== connection.approvedOrigin) {
      pauseForOrigin(url);
      return;
    }
    const metrics = await cdp("Page.getLayoutMetrics");
    const viewport = metrics.cssVisualViewport;
    send({
      kind: "frame",
      image: params.data,
      width: Math.round(viewport.clientWidth),
      height: Math.round(viewport.clientHeight),
      page_epoch: String(params.sessionId),
      url
    });
  } catch {
    granted = false;
    if (connection) update({ ...connection.session, controller: null });
    send({ kind: "paused" });
  } finally {
    await cdp("Page.screencastFrameAck", { sessionId: params.sessionId }).catch(() => {
    });
  }
});
chrome.runtime.onMessage.addListener((message, _sender, respond) => {
  void (async () => {
    if (message.kind === "pair") {
      const invite = new URL(message.invitation);
      if (invite.pathname !== "/_browser/guest/join" || invite.username || invite.password || invite.protocol !== "https:" && !["localhost", "127.0.0.1"].includes(invite.hostname))
        throw new Error("Use a valid invitation from your control plane");
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) throw new Error("Open the application tab before sharing");
      if (!tab.url) throw new Error(
        "Chrome could not read this tab's address. Select the application tab, click the Evander Browser Assistance toolbar icon to grant access, then try again."
      );
      if (!/^https?:/.test(tab.url)) throw new Error(
        "This page cannot be shared. Open an application page with an http:// or https:// address."
      );
      const response = await fetch(invite.origin + "/_browser/guest/pair", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "omit",
        redirect: "error",
        body: JSON.stringify({
          invitation: new URLSearchParams(invite.hash.slice(1)).get("invite"),
          application_url: tab.url
        })
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "Invitation is unavailable");
      await disconnect(false);
      tabId = tab.id;
      connection = { ...result, base: invite.origin, tabId, approvedOrigin: new URL(tab.url).origin };
      granted = false;
      deniedOrigin = void 0;
      clearTimeout(expiry);
      expiry = setTimeout(
        () => void disconnect(false),
        Math.max(1, connection.session.expires_at * 1e3 - Date.now())
      );
      await chrome.storage.session.set({ connection });
      try {
        await attach();
      } catch (error) {
        await disconnect();
        throw new Error(`${error.message} Request a new invitation after resolving this error.`);
      }
      return { session: connection.session };
    }
    if (message.kind === "state") {
      if (!connection) return { session: null };
      const result = await api("state?after=" + Number(message.after ?? 0));
      update(result.session);
      return { ...result, granted, connected: socket?.readyState === WebSocket.OPEN };
    }
    if (message.kind === "control") {
      granted = message.action === "grant";
      if (!granted && connection) update({ ...connection.session, controller: null });
      try {
        const result = await api("control", {
          action: message.action,
          expected_generation: connection.session.control_generation
        });
        update(result);
        return { session: result };
      } catch (error) {
        granted = false;
        throw error;
      }
    }
    if (message.kind === "message") return api("message", { request_id: crypto.randomUUID(), body: message.body });
    if (message.kind === "voice") {
      const result = await api("voice", {});
      await chrome.tabs.create({ url: result.voice_url });
      return { opened: true };
    }
    if (message.kind === "origin") {
      const tree = await cdp("Page.getFrameTree");
      const url = tree.frameTree.frame.url;
      const approvedOrigin = new URL(url).origin;
      granted = false;
      const result = await api("origin", { url });
      connection.approvedOrigin = approvedOrigin;
      deniedOrigin = void 0;
      update(result);
      return { session: result };
    }
    if (message.kind === "disconnect") {
      await disconnect();
      return { session: null };
    }
    throw new Error("Unknown extension operation");
  })().then((result) => respond({ ok: true, ...result }), (error) => respond({ ok: false, error: error.message }));
  return true;
});
