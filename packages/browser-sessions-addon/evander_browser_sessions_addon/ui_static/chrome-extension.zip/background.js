// shared/engine.ts
var BrowserEngine = class {
  constructor(send2, state, emit) {
    this.send = send2;
    this.state = state;
    this.emit = emit;
  }
  observation = "";
  refs = /* @__PURE__ */ new Map();
  epoch = 0;
  update(state) {
    this.state = state;
  }
  navigate() {
    this.epoch += 1;
    this.observation = "";
    this.refs.clear();
  }
  async location() {
    const tree = await this.send("Page.getFrameTree");
    return tree.frameTree.frame.url;
  }
  guard(command, actor, epoch) {
    if (Date.now() / 1e3 >= this.state.expires_at) throw new Error("session_expired");
    if (command.generation !== this.state.control_generation) throw new Error("stale_control");
    if (!["observe", "highlight"].includes(command.action) && this.state.controller !== actor)
      throw new Error("control_required");
    if (epoch !== void 0 && epoch !== this.epoch) throw new Error("stale_observation");
  }
  async execute(command, actor) {
    const epoch = this.epoch;
    const fence = async () => {
      this.guard(command, actor, epoch);
      const current = await this.location();
      this.guard(command, actor, epoch);
      if (!this.state.allowed_origins.includes(new URL(current).origin)) throw new Error("origin_denied");
      return current;
    };
    const input = async (method, params = {}) => {
      await fence();
      this.guard(command, actor, epoch);
      return this.send(method, params);
    };
    const press = async (key, text, code, keyCode) => {
      const identity = {
        key,
        ...code ? { code } : {},
        ...keyCode ? { windowsVirtualKeyCode: keyCode } : {}
      };
      await input("Input.dispatchKeyEvent", {
        type: "keyDown",
        ...identity,
        ...text !== void 0 ? { text, unmodifiedText: text } : {}
      });
      await input("Input.dispatchKeyEvent", { type: "keyUp", ...identity });
    };
    const url = await fence();
    if (command.action === "observe") {
      const before = this.epoch;
      const { nodes } = await this.send("Accessibility.getFullAXTree");
      this.refs.clear();
      const elements = [];
      const roles = /* @__PURE__ */ new Set([
        "button",
        "link",
        "textbox",
        "combobox",
        "checkbox",
        "radio",
        "tab",
        "menuitem",
        "option",
        "heading",
        "dialog",
        "alert",
        "gridcell",
        "row"
      ]);
      for (const node of nodes ?? []) {
        if (elements.length >= 600) break;
        const role = node.role?.value;
        if (node.ignored || !node.backendDOMNodeId || !roles.has(role)) continue;
        const ref = "node-" + node.backendDOMNodeId;
        this.refs.set(ref, node.backendDOMNodeId);
        elements.push({ ref, role, name: String(node.name?.value ?? "").slice(0, 400) });
      }
      let screenshot;
      for (let attempt = 0; attempt < 3; attempt++) {
        try {
          screenshot = await this.send("Page.captureScreenshot", {
            format: "jpeg",
            quality: 65,
            captureBeyondViewport: false
          });
          break;
        } catch (error) {
          if (attempt === 2) throw error;
          await new Promise((resolve) => setTimeout(resolve, 75));
        }
      }
      await fence();
      if (before !== this.epoch) throw new Error("stale_observation");
      this.observation = crypto.randomUUID();
      return {
        observation_id: this.observation,
        page_epoch: String(this.epoch),
        url,
        elements,
        image: screenshot.data,
        mime_type: "image/jpeg"
      };
    }
    if (!["navigate", "reload"].includes(command.action) && command.observation_id !== this.observation)
      throw new Error("stale_observation");
    if (command.action === "navigate") {
      if (!this.state.allowed_origins.includes(new URL(command.url).origin)) throw new Error("origin_denied");
      await input("Page.navigate", { url: command.url });
      this.navigate();
      return { success: true };
    }
    if (command.action === "reload") {
      await input("Page.reload");
      this.navigate();
      return { success: true };
    }
    let x = command.x, y = command.y;
    if (command.ref && ["click", "hover", "highlight"].includes(command.action)) {
      const backendNodeId = this.refs.get(command.ref);
      if (!backendNodeId) throw new Error("stale_observation");
      if (command.action !== "highlight") {
        await input("DOM.scrollIntoViewIfNeeded", { backendNodeId });
        await fence();
      }
      const { model } = await this.send("DOM.getBoxModel", { backendNodeId });
      x = (model.content[0] + model.content[4]) / 2;
      y = (model.content[1] + model.content[5]) / 2;
    }
    const metrics = await this.send("Page.getLayoutMetrics");
    const viewport = metrics.cssVisualViewport ?? metrics.visualViewport;
    if (["click", "hover", "highlight"].includes(command.action)) {
      if (!Number.isFinite(x) || !Number.isFinite(y) || x < 0 || y < 0 || x > viewport.clientWidth || y > viewport.clientHeight) throw new Error("invalid_coordinates");
      await fence();
      this.emit({ kind: "pointer", x, y, action: command.action });
      if (command.action === "highlight") return { success: true };
      this.guard(command, actor);
      await input("Input.dispatchMouseEvent", { type: "mouseMoved", x, y });
      if (command.action === "click") {
        this.guard(command, actor);
        await input("Input.dispatchMouseEvent", { type: "mousePressed", x, y, button: "left", clickCount: 1 });
        await input("Input.dispatchMouseEvent", { type: "mouseReleased", x, y, button: "left", clickCount: 1 });
      }
    } else if (command.action === "fill") {
      const backendNodeId = this.refs.get(command.ref);
      if (!backendNodeId) throw new Error("stale_observation");
      await input("DOM.focus", { backendNodeId });
      this.guard(command, actor);
      await input("Input.dispatchKeyEvent", { type: "keyDown", key: "a", code: "KeyA", modifiers: 2, windowsVirtualKeyCode: 65 });
      await input("Input.dispatchKeyEvent", { type: "keyUp", key: "a", code: "KeyA", modifiers: 2, windowsVirtualKeyCode: 65 });
      this.guard(command, actor);
      await input("Input.insertText", { text: command.text ?? "" });
    } else if (command.action === "type") {
      for (const character of (command.text ?? "").replace(/\r\n/g, "\n")) {
        const newline = character === "\n" || character === "\r";
        await press(
          newline ? "Enter" : character,
          newline ? "\r" : character,
          newline ? "Enter" : character === " " ? "Space" : void 0,
          newline ? 13 : character === " " ? 32 : void 0
        );
      }
    } else if (command.action === "key") {
      const keys = {
        Enter: 13,
        Tab: 9,
        Escape: 27,
        Backspace: 8,
        Delete: 46,
        ArrowLeft: 37,
        ArrowUp: 38,
        ArrowRight: 39,
        ArrowDown: 40,
        Space: 32
      };
      const key = command.text;
      if (!keys[key]) throw new Error("unsupported_key");
      await press(
        key === "Space" ? " " : key,
        key === "Enter" ? "\r" : key === "Space" ? " " : void 0,
        key,
        keys[key]
      );
    } else if (command.action === "scroll") {
      this.guard(command, actor);
      await input("Input.dispatchMouseEvent", {
        type: "mouseWheel",
        x: x ?? 10,
        y: y ?? 10,
        deltaX: command.delta_x ?? 0,
        deltaY: command.delta_y ?? 0
      });
    } else if (command.action === "dialog") {
      this.guard(command, actor);
      await input("Page.handleJavaScriptDialog", { accept: command.accept === true });
    } else {
      throw new Error("unsupported_action");
    }
    return { success: true, url: await this.location() };
  }
};

// extension/compatible-dom.ts
function applicationDOM(method, params, origin) {
  if (location.origin !== origin) return { error: "origin_denied" };
  const scope = globalThis;
  const state = scope.__evanderApplicationDOM ??= {
    ids: /* @__PURE__ */ new WeakMap(),
    nodes: /* @__PURE__ */ new Map(),
    next: 1,
    pressed: null,
    dirty: /* @__PURE__ */ new WeakSet()
  };
  const element = (id) => {
    const value = state.nodes.get(id)?.deref();
    if (!value?.isConnected) throw new Error("stale_observation");
    return value;
  };
  const hit = (x, y) => {
    let value = document.elementFromPoint(x, y);
    while (value?.shadowRoot) {
      const inner = value.shadowRoot.elementFromPoint(x, y);
      if (!inner || inner === value) break;
      value = inner;
    }
    if (!value || value.closest("iframe,frame,object,embed")) throw new Error("unsupported_target");
    return value;
  };
  const active = (allowFrame = false) => {
    let value = document.activeElement;
    while (value?.shadowRoot?.activeElement) value = value.shadowRoot.activeElement;
    if (!value || !allowFrame && value.matches("iframe,frame,object,embed")) throw new Error("unsupported_target");
    return value;
  };
  const edit = (target, text, inputType = "insertText") => {
    if (target.matches(":disabled") || target.getAttribute("readonly") !== null) throw new Error("unsupported_target");
    if (!target.dispatchEvent(new InputEvent("beforeinput", {
      bubbles: true,
      composed: true,
      cancelable: true,
      inputType,
      data: text
    }))) return;
    if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) {
      const replace = state.replace === target;
      state.replace = null;
      const start = replace ? 0 : target.selectionStart ?? target.value.length;
      const end = replace ? target.value.length : target.selectionEnd ?? start;
      const value = target.value.slice(0, start) + text + target.value.slice(end);
      const prototype = target instanceof HTMLInputElement ? HTMLInputElement.prototype : HTMLTextAreaElement.prototype;
      Object.getOwnPropertyDescriptor(prototype, "value").set.call(target, value);
      try {
        target.setSelectionRange(start + text.length, start + text.length);
      } catch {
      }
    } else if (target.isContentEditable) {
      const selection = getSelection();
      if (!selection?.rangeCount || !target.contains(selection.anchorNode)) throw new Error("unsupported_target");
      const range = selection.getRangeAt(0);
      range.deleteContents();
      const node = document.createTextNode(text);
      range.insertNode(node);
      range.setStartAfter(node);
      range.collapse(true);
      selection.removeAllRanges();
      selection.addRange(range);
    } else return;
    state.dirty.add(target);
    target.dispatchEvent(new InputEvent("input", { bubbles: true, composed: true, inputType, data: text }));
  };
  try {
    if (method === "Page.getFrameTree") return { frameTree: { frame: { id: "main", url: location.href } } };
    if (method === "Page.getLayoutMetrics") return { cssVisualViewport: {
      clientWidth: innerWidth,
      clientHeight: innerHeight
    } };
    if (method === "Accessibility.getFullAXTree") {
      state.nodes.clear();
      const nodes = [];
      const name = (node) => {
        const labelled = (node.getAttribute("aria-labelledby") ?? "").split(/\s+/).map((id) => node.getRootNode() instanceof Document ? document.getElementById(id)?.textContent : node.getRootNode().getElementById(id)?.textContent).filter(Boolean).join(" ");
        return (labelled || node.getAttribute("aria-label") || node.labels && Array.from(node.labels).map((label) => label.textContent).join(" ") || node.getAttribute("alt") || node.getAttribute("title") || (node instanceof HTMLInputElement && ["button", "submit", "reset"].includes(node.type) ? node.value : node.textContent) || "").replace(/\s+/g, " ").trim().slice(0, 400);
      };
      const walk = (root) => {
        for (const node of Array.from(root.querySelectorAll("*"))) {
          if (nodes.length >= 600) return;
          if (node.shadowRoot) walk(node.shadowRoot);
          if (node.closest('[hidden],[inert],[aria-hidden="true"]') || getComputedStyle(node).visibility === "hidden" || getComputedStyle(node).display === "none") continue;
          const tag = node.tagName.toLowerCase();
          const role = node.getAttribute("role")?.split(/\s+/)[0] || (node instanceof HTMLInputElement ? { checkbox: "checkbox", radio: "radio", button: "button", submit: "button", reset: "button", hidden: "" }[node.type] ?? "textbox" : {
            button: "button",
            a: node.hasAttribute("href") ? "link" : "",
            textarea: "textbox",
            select: "combobox",
            option: "option",
            h1: "heading",
            h2: "heading",
            h3: "heading",
            h4: "heading",
            h5: "heading",
            h6: "heading",
            dialog: "dialog",
            tr: "row",
            td: "gridcell",
            th: "gridcell"
          }[tag]);
          if (!role || !["button", "link", "textbox", "combobox", "checkbox", "radio", "tab", "menuitem", "option", "heading", "dialog", "alert", "gridcell", "row"].includes(role)) continue;
          let id = state.ids.get(node);
          if (!id) {
            id = state.next++;
            state.ids.set(node, id);
          }
          state.nodes.set(id, new WeakRef(node));
          nodes.push({ backendDOMNodeId: id, role: { value: role }, name: { value: name(node) } });
        }
      };
      walk(document);
      return { nodes };
    }
    if (method === "DOM.scrollIntoViewIfNeeded") {
      element(params.backendNodeId).scrollIntoView({ block: "nearest", inline: "nearest", behavior: "instant" });
      return {};
    }
    if (method === "DOM.getBoxModel") {
      const rect = element(params.backendNodeId).getBoundingClientRect();
      return { model: { content: [rect.left, rect.top, rect.right, rect.top, rect.right, rect.bottom, rect.left, rect.bottom] } };
    }
    if (method === "DOM.focus") {
      const prior = active(true);
      if (state.dirty.delete(prior)) prior.dispatchEvent(new Event("change", { bubbles: true }));
      const node = element(params.backendNodeId);
      node.focus();
      if (active() !== node) throw new Error("unsupported_target");
      if (node.isContentEditable && !node.contains(getSelection()?.anchorNode ?? null)) {
        const range = document.createRange();
        range.selectNodeContents(node);
        range.collapse(false);
        getSelection()?.removeAllRanges();
        getSelection()?.addRange(range);
      }
      return {};
    }
    if (method === "Input.insertText") {
      const target = active();
      if (!(target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target.isContentEditable)) throw new Error("unsupported_target");
      edit(target, params.text);
      return {};
    }
    if (method === "Input.dispatchKeyEvent") {
      const target = active(), down = params.type === "keyDown";
      const keyCode = params.windowsVirtualKeyCode ?? (params.key?.length === 1 ? params.key.toUpperCase().charCodeAt(0) : 0);
      const options = {
        key: params.key,
        code: params.code ?? "",
        keyCode,
        which: keyCode,
        ctrlKey: !!(params.modifiers & 2),
        bubbles: true,
        composed: true,
        cancelable: true
      };
      const accepted = target.dispatchEvent(new KeyboardEvent(down ? "keydown" : "keyup", options));
      if (!down || !accepted) return {};
      if (options.ctrlKey && params.key === "a") {
        if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) {
          target.select();
          state.replace = target;
        } else if (target.isContentEditable) {
          const range = document.createRange();
          range.selectNodeContents(target);
          getSelection()?.removeAllRanges();
          getSelection()?.addRange(range);
        }
      } else if (params.text !== void 0) {
        const character = params.text.charCodeAt(0);
        if (target.dispatchEvent(new KeyboardEvent("keypress", { ...options, charCode: character, keyCode: character, which: character }))) {
          if (params.key === "Enter" && !(target instanceof HTMLTextAreaElement) && !target.isContentEditable) {
            if (target instanceof HTMLInputElement) target.form?.requestSubmit();
            else if (target.matches("button,a[href]")) target.click();
          } else if (params.key === " " && target.matches("button,input[type=checkbox],input[type=radio]")) target.click();
          else edit(target, params.text === "\r" ? "\n" : params.text);
        }
      } else if (params.key === "Tab") {
        const items = Array.from(document.querySelectorAll("a[href],button,input,textarea,select,[tabindex]")).filter((node) => !node.matches(":disabled,[hidden]") && node.tabIndex >= 0 && node.getClientRects().length);
        items[(items.indexOf(target) + 1) % items.length]?.focus();
      } else if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement) {
        const start = target.selectionStart, end = target.selectionEnd;
        if (start !== null && end !== null) {
          if (params.key === "Backspace" || params.key === "Delete") {
            const left = start === end && params.key === "Backspace" ? Math.max(0, start - 1) : start;
            const right = start === end && params.key === "Delete" ? end + 1 : end;
            target.setSelectionRange(left, right);
            edit(target, "", params.key === "Backspace" ? "deleteContentBackward" : "deleteContentForward");
          } else if (params.key === "ArrowLeft" || params.key === "ArrowRight") {
            const position = params.key === "ArrowLeft" ? Math.max(0, start - 1) : Math.min(target.value.length, end + 1);
            target.setSelectionRange(position, position);
          }
        }
      }
      return {};
    }
    if (method === "Input.dispatchMouseEvent") {
      const target = hit(params.x, params.y);
      const options = { clientX: params.x, clientY: params.y, bubbles: true, composed: true, cancelable: true, button: 0 };
      if (params.type === "mouseWheel") {
        if (!target.dispatchEvent(new WheelEvent("wheel", { ...options, deltaX: params.deltaX, deltaY: params.deltaY }))) return {};
        let scroll = target;
        while (scroll && !(scroll.scrollHeight > scroll.clientHeight && /auto|scroll/.test(getComputedStyle(scroll).overflowY))) scroll = scroll.parentElement;
        (scroll ?? document.scrollingElement)?.scrollBy({ left: params.deltaX, top: params.deltaY, behavior: "instant" });
      } else if (params.type === "mouseMoved") {
        if (state.hovered !== target) {
          if (state.hovered?.isConnected) {
            state.hovered.dispatchEvent(new PointerEvent("pointerleave", { ...options, bubbles: false, pointerId: 1, pointerType: "mouse" }));
            state.hovered.dispatchEvent(new MouseEvent("mouseleave", { ...options, bubbles: false }));
            state.hovered.dispatchEvent(new MouseEvent("mouseout", options));
          }
          target.dispatchEvent(new PointerEvent("pointerenter", { ...options, bubbles: false, pointerId: 1, pointerType: "mouse" }));
          target.dispatchEvent(new MouseEvent("mouseover", options));
          target.dispatchEvent(new MouseEvent("mouseenter", { ...options, bubbles: false }));
          state.hovered = target;
        }
        target.dispatchEvent(new PointerEvent("pointermove", { ...options, pointerId: 1, pointerType: "mouse" }));
        target.dispatchEvent(new MouseEvent("mousemove", options));
      } else if (params.type === "mousePressed") {
        const pointer = target.dispatchEvent(new PointerEvent("pointerdown", { ...options, pointerId: 1, pointerType: "mouse", buttons: 1 }));
        const mouse = target.dispatchEvent(new MouseEvent("mousedown", { ...options, buttons: 1 }));
        state.pressed = pointer && mouse ? target : null;
        if (state.pressed) {
          const prior = active(true);
          if (prior !== target && state.dirty.delete(prior)) prior.dispatchEvent(new Event("change", { bubbles: true }));
          target.focus();
        }
      } else if (params.type === "mouseReleased") {
        target.dispatchEvent(new PointerEvent("pointerup", { ...options, pointerId: 1, pointerType: "mouse" }));
        target.dispatchEvent(new MouseEvent("mouseup", options));
        if (state.pressed === target) target.click();
        state.pressed = null;
      }
      return {};
    }
    if (method === "Page.navigate") {
      location.assign(params.url);
      return {};
    }
    if (method === "Page.reload") {
      location.reload();
      return {};
    }
    throw new Error("compatibility_unsupported");
  } catch (error) {
    return { error: error.message };
  }
}

// extension/compatible-tab.ts
var extensionConflict = (error) => /Cannot access a chrome-extension:\/\/ URL of different extension/i.test(String(error?.message ?? error));
var CompatibleTab = class {
  constructor(tabId2, origin, current, navigated) {
    this.tabId = tabId2;
    this.origin = origin;
    this.current = current;
    this.navigated = navigated;
  }
  documentId;
  revision = 0;
  disposed = false;
  owner = crypto.randomUUID();
  captured = false;
  setup;
  check() {
    if (this.disposed || !this.current()) throw new Error("disconnected");
  }
  navigate() {
    this.documentId = void 0;
    this.revision++;
    this.navigated();
  }
  async captureMessage(kind, extra = {}) {
    let timeout;
    let result;
    try {
      result = await Promise.race([
        chrome.runtime.sendMessage({ target: "tab-capture", kind, owner: this.owner, ...extra }),
        new Promise((_, reject) => {
          timeout = setTimeout(() => reject(new Error("capture_unavailable")), 8e3);
        })
      ]);
    } finally {
      clearTimeout(timeout);
    }
    if (!result?.ok) throw new Error(result?.error ?? "capture_unavailable");
    return result;
  }
  start() {
    this.setup = this.initialize();
    return this.setup;
  }
  async initialize() {
    this.check();
    await this.send("Page.getFrameTree");
    if (!await chrome.offscreen.hasDocument()) {
      await chrome.offscreen.createDocument({
        url: "capture.html",
        reasons: ["USER_MEDIA"],
        justification: "Share video of the one application tab approved by the user."
      });
    }
    this.check();
    await this.captureMessage("stop");
    this.captured = false;
    let streamId;
    try {
      streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: this.tabId });
    } catch {
      throw new Error("Select the application tab, click the Evander toolbar icon, then try sharing again to allow tab capture.");
    }
    this.check();
    await this.captureMessage("start", { streamId });
    this.check();
    this.captured = true;
  }
  async stop() {
    this.disposed = true;
    this.revision++;
    await this.setup?.catch(() => {
    });
    if (await chrome.offscreen.hasDocument()) await chrome.offscreen.closeDocument().catch(() => {
    });
    this.captured = false;
  }
  async suspend() {
    this.captured = false;
    this.revision++;
    await this.captureMessage("stop").catch(() => {
    });
  }
  async send(method, params = {}) {
    this.check();
    const revision = this.revision;
    if (method === "Page.captureScreenshot") {
      if (!this.captured) throw new Error("origin_denied");
      await this.send("Page.getFrameTree");
      const documentId = this.documentId;
      const metrics = await this.send("Page.getLayoutMetrics");
      const frame = await this.captureMessage("frame", { viewport: metrics.cssVisualViewport });
      this.check();
      await this.send("Page.getFrameTree");
      if (documentId !== this.documentId || revision !== this.revision) throw new Error("stale_observation");
      return frame;
    }
    const target = method === "Page.getFrameTree" || !this.documentId ? { tabId: this.tabId, frameIds: [0] } : { tabId: this.tabId, documentIds: [this.documentId] };
    let results;
    try {
      results = await chrome.scripting.executeScript({
        target,
        world: "ISOLATED",
        func: applicationDOM,
        args: [method, params, this.origin()]
      });
    } catch {
      throw new Error("origin_denied");
    }
    this.check();
    if (revision !== this.revision) throw new Error("stale_observation");
    const result = results[0];
    if (!result?.documentId || !result.result) throw new Error("stale_observation");
    if (this.documentId && result.documentId !== this.documentId) {
      this.documentId = result.documentId;
      this.revision++;
      this.navigated();
      throw new Error("stale_observation");
    }
    this.documentId = result.documentId;
    if (result.result.error) throw new Error(result.result.error);
    return result.result;
  }
};

// extension/background.ts
var connection;
var socket;
var engine;
var tabId;
var granted = false;
var retry;
var chain = Promise.resolve();
var streaming = false;
var heartbeat;
var expiry;
var deniedOrigin;
var mainFrameId;
var compatible;
var frameTimer;
var upgrading;
chrome.action.onClicked.addListener(async (tab) => {
  if (!connection) tabId = tab.id;
  await chrome.sidePanel.open({ tabId: tab.id });
});
function send(message) {
  if (socket?.readyState === WebSocket.OPEN) socket.send(JSON.stringify(message));
}
async function cdp(method, params = {}) {
  if (!tabId) throw new Error("tab_closed");
  if (compatible) return compatible.send(method, params);
  try {
    return await chrome.debugger.sendCommand({ tabId }, method, params);
  } catch (error) {
    if (connection && extensionConflict(error)) {
      await useCompatibility(true);
      throw new Error("stale_control");
    }
    throw error;
  }
}
function update(state) {
  if (!connection || state.id !== connection.session.id) return;
  connection.session = { ...state, allowed_origins: [connection.approvedOrigin] };
  if (!granted) connection.session.controller = null;
  engine?.update(connection.session);
}
function pauseForOrigin(url) {
  if (!connection) return;
  let currentOrigin;
  try {
    currentOrigin = new URL(url).origin;
  } catch {
    currentOrigin = "null";
  }
  if (currentOrigin === connection.approvedOrigin) return;
  granted = false;
  update({ ...connection.session, controller: null });
  if (!deniedOrigin) send({ kind: "paused" });
  deniedOrigin = currentOrigin;
  void compatible?.suspend();
}
async function api(action, body) {
  if (!connection) throw new Error("Share a tab first");
  const current = connection;
  const response = await fetch(current.base + "/_browser/guest/" + action, {
    method: body ? "POST" : "GET",
    headers: { "Authorization": "Bearer " + current.host_token, ...body ? { "Content-Type": "application/json" } : {} },
    body: body ? JSON.stringify(body) : void 0,
    credentials: "omit",
    redirect: "error"
  });
  const result = await response.json();
  if (connection !== current) throw new Error("The sharing session changed. Try again.");
  if (!response.ok) {
    const error = new Error(result.error ?? "Support session unavailable");
    error.status = response.status;
    throw error;
  }
  return result;
}
async function overlay(message) {
  if (!tabId) return;
  await chrome.scripting.executeScript({
    target: { tabId },
    func: (x, y) => {
      let dot = document.getElementById("__evander_agent_pointer");
      if (!dot) {
        dot = document.createElement("div");
        dot.id = "__evander_agent_pointer";
        dot.setAttribute("aria-label", "Truman pointer");
        Object.assign(dot.style, {
          position: "fixed",
          width: "18px",
          height: "18px",
          border: "3px solid #aa36ff",
          borderRadius: "50%",
          pointerEvents: "none",
          zIndex: "2147483647",
          transition: "left 120ms, top 120ms",
          boxShadow: "0 0 0 4px #aa36ff30"
        });
        document.documentElement.append(dot);
      }
      dot.style.left = String(x - 9) + "px";
      dot.style.top = String(y - 9) + "px";
    },
    args: [message.x, message.y]
  });
}
async function connectEndpoint() {
  if (!connection || !tabId || !engine) return;
  streaming = false;
  const current = connection;
  socket?.close();
  const endpointSocket = new WebSocket(connection.base.replace(/^http/, "ws") + "/_browser/extension");
  socket = endpointSocket;
  endpointSocket.addEventListener("open", () => {
    if (connection === current && socket === endpointSocket)
      endpointSocket.send(JSON.stringify({ kind: "authenticate", version: 1, token: current.endpoint_token }));
  });
  endpointSocket.addEventListener("error", () => endpointSocket.close());
  endpointSocket.addEventListener("message", (event) => {
    if (connection !== current || socket !== endpointSocket) return;
    let message;
    try {
      message = JSON.parse(String(event.data));
    } catch {
      socket?.close();
      return;
    }
    if (message.kind === "state") {
      if (connection !== current) return;
      update(message.session);
      if (compatible && !streaming) {
        streaming = true;
        void cdp("Page.getFrameTree").then((tree) => {
          if (connection === current) send({ kind: "ready", url: tree.frameTree.frame.url });
        }).catch(() => {
        });
      } else if (!streaming) {
        streaming = true;
        void cdp("Page.startScreencast", { format: "jpeg", quality: 65, maxWidth: 1920, maxHeight: 1080 });
        void cdp("Page.getFrameTree").then((tree) => send({ kind: "ready", url: tree.frameTree.frame.url }));
      }
    } else if (message.kind === "pause") {
      granted = false;
      update({ ...connection.session, controller: null });
    } else if (message.kind === "command") {
      const endpoint = engine;
      chain = chain.then(async () => {
        try {
          if (connection !== current || engine !== endpoint) throw new Error("disconnected");
          const result = await endpoint.execute(message.command, message.actor);
          if (connection !== current) return;
          send({ kind: "result", id: message.command.id, result });
        } catch (error) {
          if (connection !== current) return;
          send({
            kind: "result",
            id: message.command.id,
            error: true,
            code: /^[a-z_]+$/.test(error.message) ? error.message : "browser_error"
          });
        }
      });
    }
  });
  endpointSocket.addEventListener("close", (event) => {
    if (connection !== current || socket !== endpointSocket) return;
    if (event.code === 1008) {
      void disconnect(false);
      return;
    }
    granted = false;
    if (connection) update({ ...connection.session, controller: null });
    if (connection === current && tabId) retry = setTimeout(() => void connectEndpoint(), 3e3);
  });
  clearInterval(heartbeat);
  heartbeat = setInterval(() => send({ kind: "heartbeat" }), 2e4);
}
function createEngine(current) {
  return new BrowserEngine(async (method, params) => {
    if (connection !== current) throw new Error("disconnected");
    const result = await cdp(method, params);
    if (connection !== current) throw new Error("disconnected");
    return result;
  }, current.session, (message) => {
    if (connection !== current) return;
    send(message);
    void overlay(message).catch(() => {
    });
  });
}
async function useCompatibility(pause = false) {
  if (upgrading) return upgrading;
  const current = connection, selected = tabId;
  if (!current || !selected) throw new Error("disconnected");
  upgrading = (async () => {
    if (pause) {
      granted = false;
      update({ ...current.session, controller: null });
      send({ kind: "paused" });
    }
    compatible = new CompatibleTab(
      selected,
      () => current.approvedOrigin,
      () => connection === current,
      () => engine?.navigate()
    );
    try {
      await chrome.debugger.detach({ tabId: selected });
    } catch {
    }
    engine = createEngine(current);
    await compatible.start();
    if (connection !== current) throw new Error("disconnected");
    current.mode = "compatibility";
    await chrome.storage.session.set({ connection: current });
    clearInterval(frameTimer);
    let busy = false;
    frameTimer = setInterval(() => {
      if (busy || connection !== current || socket?.readyState !== WebSocket.OPEN || deniedOrigin) return;
      busy = true;
      void (async () => {
        const tree = await cdp("Page.getFrameTree");
        const image = await cdp("Page.captureScreenshot");
        const metrics = await cdp("Page.getLayoutMetrics");
        if (connection !== current || deniedOrigin) return;
        send({
          kind: "frame",
          image: image.data,
          width: Math.round(metrics.cssVisualViewport.clientWidth),
          height: Math.round(metrics.cssVisualViewport.clientHeight),
          page_epoch: "compatible",
          url: tree.frameTree.frame.url
        });
      })().catch(() => {
        if (connection === current) {
          granted = false;
          update({ ...current.session, controller: null });
          send({ kind: "paused" });
        }
      }).finally(() => {
        busy = false;
      });
    }, 1e3);
  })();
  try {
    await upgrading;
  } finally {
    upgrading = void 0;
  }
}
async function attach() {
  if (!connection || !tabId) throw new Error("Select the application tab");
  let step = "attaching Chrome to the tab";
  try {
    try {
      await chrome.debugger.attach({ tabId }, "1.3");
    } catch (error) {
      if (!extensionConflict(error)) throw error;
      step = "starting extension-compatible sharing";
      await useCompatibility();
      await connectEndpoint();
      return;
    }
    step = "preparing the shared browser";
    engine = createEngine(connection);
    step = "enabling page access";
    await cdp("Page.enable");
    step = "reading the page frame";
    mainFrameId = (await cdp("Page.getFrameTree")).frameTree.frame.id;
    step = "enabling accessibility";
    await cdp("Accessibility.enable");
    step = "connecting to Truman";
    await connectEndpoint();
  } catch (error) {
    const reason = String(error?.message ?? error ?? "Unknown browser error").replace(/\s+/g, " ").slice(0, 400);
    throw new Error(`Browser setup failed while ${step}: ${reason}`);
  }
}
async function disconnect(close = true) {
  const previous = connection;
  if (connection) engine?.update({ ...connection.session, controller: null, control_generation: connection.session.control_generation + 1 });
  connection = void 0;
  granted = false;
  clearTimeout(retry);
  clearTimeout(expiry);
  clearInterval(heartbeat);
  clearInterval(frameTimer);
  socket?.close();
  engine = void 0;
  const capture = compatible;
  compatible = void 0;
  await capture?.stop();
  if (tabId) {
    try {
      await chrome.debugger.detach({ tabId });
    } catch {
    }
  }
  await chrome.storage.session.remove("connection");
  if (close && previous) {
    await fetch(previous.base + "/_browser/guest/close", {
      method: "POST",
      headers: { "Authorization": "Bearer " + previous.host_token, "Content-Type": "application/json" },
      body: "{}",
      credentials: "omit",
      redirect: "error"
    }).catch(() => {
    });
  }
}
chrome.debugger.onDetach.addListener((source, reason) => {
  if (source.tabId !== tabId || !connection || compatible) return;
  const current = connection;
  granted = false;
  update({ ...current.session, controller: null });
  send({ kind: "paused" });
  engine?.navigate();
  void (async () => {
    const tab = reason === "target_closed" ? await chrome.tabs.get(source.tabId).catch(() => null) : null;
    if (connection !== current) return;
    if (tab?.url && new URL(tab.url).origin === current.approvedOrigin) {
      try {
        await attach();
        return;
      } catch {
      }
    }
    if (connection === current) await disconnect();
  })();
});
chrome.tabs.onRemoved.addListener((id) => {
  if (id === tabId) void disconnect();
});
chrome.tabs.onUpdated.addListener((id, change, tab) => {
  if (id !== tabId || !connection || !compatible) return;
  if (change.status === "loading" || change.url) compatible.navigate();
  if (change.url || change.status === "loading") pauseForOrigin(tab.url ?? "about:blank");
});
chrome.debugger.onEvent.addListener(async (source, method, params) => {
  if (source.tabId !== tabId || !connection || !engine || compatible) return;
  if (method === "Page.frameNavigated" || method === "Page.navigatedWithinDocument") {
    engine.navigate();
    if (method === "Page.frameNavigated" && !params.frame.parentId) {
      mainFrameId = params.frame.id;
      pauseForOrigin(params.frame.url);
    } else if (method === "Page.navigatedWithinDocument" && params.frameId === mainFrameId) {
      pauseForOrigin(params.url);
    }
  }
  if (method !== "Page.screencastFrame") return;
  try {
    const tree = await cdp("Page.getFrameTree");
    const url = tree.frameTree.frame.url;
    if (new URL(url).origin !== connection.approvedOrigin) {
      pauseForOrigin(url);
      return;
    }
    const metrics = await cdp("Page.getLayoutMetrics");
    const viewport = metrics.cssVisualViewport;
    send({
      kind: "frame",
      image: params.data,
      width: Math.round(viewport.clientWidth),
      height: Math.round(viewport.clientHeight),
      page_epoch: String(params.sessionId),
      url
    });
  } catch {
    granted = false;
    if (connection) update({ ...connection.session, controller: null });
    send({ kind: "paused" });
  } finally {
    await cdp("Page.screencastFrameAck", { sessionId: params.sessionId }).catch(() => {
    });
  }
});
chrome.runtime.onMessage.addListener((message, _sender, respond) => {
  if (message.kind === "microphone_permission_result" || message.target === "tab-capture") return false;
  void (async () => {
    if (message.kind === "pair") {
      const invite = new URL(message.invitation);
      if (invite.pathname !== "/_browser/guest/join" || invite.username || invite.password || invite.protocol !== "https:" && !["localhost", "127.0.0.1"].includes(invite.hostname))
        throw new Error("Use a valid invitation from your control plane");
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) throw new Error("Open the application tab before sharing");
      if (!tab.url) throw new Error(
        "Chrome could not read this tab's address. Select the application tab, click the Evander Browser Assistance toolbar icon to grant access, then try again."
      );
      if (!/^https?:/.test(tab.url)) throw new Error(
        "This page cannot be shared. Open an application page with an http:// or https:// address."
      );
      const response = await fetch(invite.origin + "/_browser/guest/pair", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "omit",
        redirect: "error",
        body: JSON.stringify({
          invitation: new URLSearchParams(invite.hash.slice(1)).get("invite"),
          application_url: tab.url
        })
      });
      const result = await response.json();
      if (!response.ok) throw new Error(result.error ?? "Invitation is unavailable");
      await disconnect(false);
      tabId = tab.id;
      connection = { ...result, base: invite.origin, tabId, approvedOrigin: new URL(tab.url).origin };
      granted = false;
      deniedOrigin = void 0;
      clearTimeout(expiry);
      expiry = setTimeout(
        () => void disconnect(false),
        Math.max(1, connection.session.expires_at * 1e3 - Date.now())
      );
      await chrome.storage.session.set({ connection });
      try {
        await attach();
      } catch (error) {
        await disconnect();
        throw new Error(`${error.message} Request a new invitation after resolving this error.`);
      }
      return { session: connection.session };
    }
    if (message.kind === "state") {
      if (!connection) return { session: null };
      const after = "browser_session_id" in message && message.browser_session_id !== connection.session.id ? 0 : Number(message.after ?? 0);
      const result = await api("state?after=" + after);
      update(result.session);
      return { ...result, granted, mode: connection.mode ?? "native", connected: socket?.readyState === WebSocket.OPEN };
    }
    if (message.kind === "control") {
      granted = message.action === "grant";
      if (!granted && connection) update({ ...connection.session, controller: null });
      try {
        const result = await api("control", {
          action: message.action,
          expected_generation: connection.session.control_generation
        });
        update(result);
        return { session: result };
      } catch (error) {
        granted = false;
        throw error;
      }
    }
    if (message.kind === "message") return api("message", { request_id: crypto.randomUUID(), body: message.body });
    if (message.kind === "voice") {
      if (_sender.id !== chrome.runtime.id || _sender.url?.split(/[?#]/)[0] !== chrome.runtime.getURL("panel.html"))
        throw new Error("Open voice controls from the sharing sidebar.");
      if (!connection || message.browser_session_id !== connection.session.id)
        throw new Error("The sharing session changed. Reopen voice controls.");
      const current = connection;
      const result = await api("voice", {});
      if (connection !== current) throw new Error("The sharing session changed. Reopen voice controls.");
      const url = new URL(result.voice_url);
      if (url.origin !== new URL(current.base).origin || url.pathname !== "/_browser/guest/voice")
        throw new Error("The voice endpoint is unavailable.");
      const token = new URLSearchParams(url.hash.slice(1)).get("token");
      if (!token) throw new Error("The voice endpoint is unavailable.");
      return { base: current.base, voice_token: token, session_id: current.session.id };
    }
    if (message.kind === "origin") {
      const url = compatible ? (await chrome.tabs.get(tabId)).url : (await cdp("Page.getFrameTree")).frameTree.frame.url;
      if (!url || !/^https?:/.test(url)) throw new Error("Select the application tab and click the Evander toolbar icon before approving it.");
      const approvedOrigin = new URL(url).origin;
      granted = false;
      const result = await api("origin", { url });
      connection.approvedOrigin = approvedOrigin;
      deniedOrigin = void 0;
      update(result);
      if (compatible) {
        compatible.navigate();
        await compatible.start();
      }
      return { session: result };
    }
    if (message.kind === "disconnect") {
      await disconnect();
      return { session: null };
    }
    throw new Error("Unknown extension operation");
  })().then((result) => respond({ ok: true, ...result }), (error) => respond({ ok: false, error: error.message, status: error.status }));
  return true;
});
