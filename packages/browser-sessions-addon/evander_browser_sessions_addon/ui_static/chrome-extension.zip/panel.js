// web/composer.ts
function enterToSend(body, form) {
  body.addEventListener("keydown", (event) => {
    if (event.key !== "Enter" || event.shiftKey || event.isComposing || event.keyCode === 229) return;
    event.preventDefault();
    if (!event.repeat && body.value.trim()) form.requestSubmit();
  });
}

// web/message-delivery.ts
var labels = {
  pending: "Sending\u2026",
  queued: "Queued for the next turn",
  steered: "Added to the active turn",
  started: "Delivered",
  delivery_unknown: "Delivery uncertain \u2014 check with your assistant before retrying",
  failed: "Delivery failed",
  cancelled: "Cancelled",
  answered: "Answered"
};
function messageDelivery(root, updates, retry) {
  const byId = new Map(updates.map((value) => [value.id, value]));
  for (const item of Array.from(root.querySelectorAll("[data-message-id]"))) {
    const update = byId.get(item.dataset.messageId);
    if (!update) continue;
    let status = item.querySelector(".message-delivery");
    if (!status) {
      status = document.createElement("small");
      status.className = "message-delivery";
      status.setAttribute("role", "status");
      item.append(status);
    }
    const state = update.status === "answered" ? "answered" : update.delivery_status ?? "pending";
    status.dataset.delivery = state;
    const label = labels[state] ?? "Sending\u2026";
    if (status.textContent !== label) status.textContent = label;
    let button = item.querySelector(".retry-delivery");
    if (state === "delivery_unknown" && retry) {
      if (!button) {
        button = document.createElement("button");
        button.className = "retry-delivery";
        button.type = "button";
        button.textContent = "Retry message";
        item.append(button);
      }
      button.disabled = false;
      button.onclick = () => {
        button.disabled = true;
        retry(update.id);
      };
    } else button?.remove();
  }
}

// web/pcm-player.ts
var PcmPlayer = class {
  context;
  cancel;
  async unlock() {
    const context = this.context ??= new AudioContext();
    await context.resume();
  }
  async play(response, signal, started) {
    const reader = response.body?.getReader();
    if (!reader) throw new Error("Spoken audio is unavailable.");
    const context = this.context ??= new AudioContext();
    const sources = /* @__PURE__ */ new Set();
    let cancelled = false, complete = false, first = true, trailing = new Uint8Array(0), total = 0;
    let next = 0;
    let drained;
    const ended = new Promise((resolve) => {
      drained = resolve;
    });
    const cancel = () => {
      cancelled = true;
      void reader.cancel().catch(() => {
      });
      for (const source of sources) source.stop();
      sources.clear();
      drained();
    };
    this.cancel = cancel;
    signal.addEventListener("abort", cancel, { once: true });
    try {
      if (signal.aborted) {
        cancel();
        return;
      }
      await context.resume();
      while (!cancelled) {
        const { value, done } = await reader.read();
        if (cancelled || signal.aborted) break;
        if (done) {
          if (trailing.length || !total) throw new Error("Spoken audio was incomplete.");
          complete = true;
          if (!sources.size) drained();
          await ended;
          break;
        }
        total += value.byteLength;
        if (total > 8e6) throw new Error("Spoken audio exceeded its limit.");
        const bytes = new Uint8Array(trailing.length + value.length);
        bytes.set(trailing);
        bytes.set(value, trailing.length);
        const count = Math.floor(bytes.length / 2);
        trailing = bytes.slice(count * 2);
        if (!count) continue;
        const buffer = context.createBuffer(1, count, 24e3);
        const samples = buffer.getChannelData(0), data = new DataView(bytes.buffer);
        for (let i = 0; i < count; i++) samples[i] = data.getInt16(i * 2, true) / 32768;
        const source = context.createBufferSource();
        source.buffer = buffer;
        source.connect(context.destination);
        sources.add(source);
        source.onended = () => {
          source.disconnect();
          sources.delete(source);
          if (complete && !sources.size) drained();
        };
        next = Math.max(next, context.currentTime + 0.05);
        source.start(next);
        next += buffer.duration;
        if (first) {
          first = false;
          started();
        }
      }
    } finally {
      if (!complete || cancelled) cancel();
      signal.removeEventListener("abort", cancel);
      reader.releaseLock();
      if (this.cancel === cancel) this.cancel = void 0;
    }
  }
  stop() {
    this.cancel?.();
  }
  dispose() {
    this.stop();
    void this.context?.close();
    this.context = void 0;
  }
};

// web/voice-controls.ts
var VoiceControls = class {
  constructor(root, transport, context = () => null) {
    this.transport = transport;
    this.context = context;
    this.talk = root.querySelector("[data-voice-talk]");
    this.replies = root.querySelector("[data-voice-replies]");
    this.stop = root.querySelector("[data-voice-stop]");
    this.microphoneOff = document.createElement("button");
    this.microphoneOff.type = "button";
    this.microphoneOff.className = "quiet";
    this.microphoneOff.textContent = "Turn off microphone";
    this.microphoneOff.hidden = true;
    this.talk.after(this.microphoneOff);
    this.status = root.querySelector("[data-voice-status]");
    const watch = (target, name, listener) => target.addEventListener(name, listener, { signal: this.events.signal });
    watch(this.talk, "pointerdown", (event) => {
      if (!this.microphoneReady || event.button !== 0) return;
      event.preventDefault();
      this.talk.focus({ preventScroll: true });
      this.talk.setPointerCapture(event.pointerId);
      void this.start();
    });
    watch(this.talk, "pointerup", () => this.finish());
    watch(this.talk, "pointercancel", () => this.finish(true));
    watch(this.talk, "blur", () => {
      const capturing = this.recording || this.opening;
      this.finish(true);
      if (capturing) this.releaseMicrophone();
    });
    watch(this.talk, "keydown", (event) => {
      if (!this.microphoneReady || ![" ", "Enter"].includes(event.key)) return;
      event.preventDefault();
      if (!event.repeat) void this.start();
    });
    watch(this.talk, "keyup", (event) => {
      if (this.microphoneReady && [" ", "Enter"].includes(event.key)) {
        event.preventDefault();
        this.finish();
      }
    });
    watch(this.talk, "click", (event) => {
      if (!this.microphoneReady) void this.enable();
      else if (event.detail === 0) {
        if (this.recording || this.opening) this.finish();
        else void this.start();
      }
    });
    watch(this.replies, "change", () => {
      if (!this.replies.checked) this.stopAudio();
      else if (typeof AudioContext !== "undefined") void this.pcm.unlock().catch(() => this.say("Audio playback needs permission."));
    });
    watch(this.stop, "click", () => this.stopAudio());
    watch(this.microphoneOff, "click", () => {
      this.finish(true);
      this.releaseMicrophone();
      this.say("");
    });
    window.addEventListener("blur", () => {
      this.finish(true);
      this.releaseMicrophone();
    }, { signal: this.events.signal });
    document.addEventListener("visibilitychange", () => {
      if (document.hidden) {
        this.finish(true);
        this.releaseMicrophone();
      }
    }, { signal: this.events.signal });
    window.addEventListener("pagehide", () => this.dispose(), { once: true, signal: this.events.signal });
    this.say("");
    void this.initialize();
  }
  talk;
  replies;
  stop;
  microphoneOff;
  pcm = new PcmPlayer();
  status;
  config;
  events = new AbortController();
  microphoneSetupAbort;
  microphoneReady = false;
  microphoneGeneration = 0;
  opening = false;
  recording = false;
  transcribing = false;
  released = false;
  discard = false;
  disposed = false;
  recorder;
  stream;
  timer;
  capture = 0;
  audio;
  audioAbort;
  transcriptionAbort;
  finishAudio;
  playback = 0;
  playing = false;
  pending = [];
  seen = /* @__PURE__ */ new Set();
  speakAfter = Infinity;
  say(text) {
    if (!this.disposed) {
      this.status.textContent = text;
      this.status.hidden = !text;
    }
  }
  async initialize() {
    try {
      this.config = await this.transport.info();
      if (this.disposed) return;
      this.speakAfter = this.config.latest_message_seq ?? 0;
      if (!this.config.enabled) {
        this.say("Voice is not configured for this directory.");
        return;
      }
      this.replies.disabled = false;
      if (this.config.microphone_available === false) {
        this.say("Microphone transcription is unavailable. Text and spoken replies remain available.");
        return;
      }
      if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") {
        this.say("Microphone recording needs Chrome over HTTPS.");
        return;
      }
      this.talk.disabled = false;
      this.say("");
    } catch (error) {
      if (!this.disposed) this.say(error.message);
    }
  }
  async enable() {
    if (this.opening || this.disposed) return;
    this.opening = true;
    this.talk.disabled = true;
    const setup = new AbortController();
    this.microphoneSetupAbort = setup;
    try {
      await this.transport.prepareMicrophone?.(setup.signal);
      if (this.disposed || setup.signal.aborted) return;
      const generation = this.microphoneGeneration;
      const stream = await navigator.mediaDevices.getUserMedia({ audio: {
        echoCancellation: true,
        noiseSuppression: false,
        autoGainControl: false
      }, video: false });
      if (this.disposed || setup.signal.aborted || document.hidden || generation !== this.microphoneGeneration) {
        stream.getTracks().forEach((track) => track.stop());
        return;
      }
      this.stream = stream;
      this.microphoneReady = true;
      this.microphoneOff.hidden = false;
      this.talk.textContent = "Hold Talk";
      this.say("");
    } catch (error) {
      if (!this.disposed) this.say(error.message || "Microphone access was denied or unavailable.");
    } finally {
      this.microphoneSetupAbort = void 0;
      this.opening = false;
      if (!this.disposed) this.talk.disabled = false;
    }
  }
  async start() {
    if (!this.config?.enabled || this.opening || this.recording || this.transcribing || this.disposed) return;
    this.stopAudio();
    this.opening = true;
    this.released = false;
    this.discard = false;
    const capture = ++this.capture;
    const context = structuredClone(this.context());
    this.say("Opening microphone\u2026");
    try {
      const stream = this.stream;
      if (!stream?.getAudioTracks().some((track) => track.readyState === "live")) {
        this.releaseMicrophone();
        this.say("Enable the microphone before holding Talk.");
        return;
      }
      const type = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4"].find((value) => MediaRecorder.isTypeSupported(value));
      if (!type) throw new Error("This browser cannot record a supported audio format.");
      const recorder = new MediaRecorder(stream, { mimeType: type });
      this.recorder = recorder;
      const chunks = [];
      let bytes = 0;
      recorder.addEventListener("dataavailable", (event) => {
        bytes += event.data.size;
        if (bytes > this.config.max_audio_bytes) {
          this.finish(true);
          this.say("Recording was too large. Try a shorter phrase.");
        } else if (event.data.size) chunks.push(event.data);
      });
      recorder.addEventListener("error", () => {
        this.finish(true);
        this.say("Microphone recording failed.");
      });
      recorder.addEventListener("stop", () => {
        clearTimeout(this.timer);
        this.recorder = void 0;
        this.recording = false;
        if (!this.disposed) this.talk.setAttribute("aria-pressed", "false");
        if (this.discard || this.disposed || capture !== this.capture) return;
        const audio = new Blob(chunks, { type });
        if (!audio.size) {
          this.say("No audio recorded. Hold Talk while speaking.");
          return;
        }
        void this.submit(audio, context);
      }, { once: true });
      this.recording = true;
      this.opening = false;
      this.talk.setAttribute("aria-pressed", "true");
      recorder.start(250);
      this.timer = setTimeout(() => this.finish(), this.config.max_recording_seconds * 1e3);
      this.say("Recording.");
      if (this.released) this.finish();
    } catch (error) {
      this.releaseMicrophone();
      this.recording = false;
      this.recorder = void 0;
      if (!this.disposed) {
        this.talk.setAttribute("aria-pressed", "false");
        if (error.name === "NotAllowedError") {
          this.microphoneReady = false;
          this.talk.textContent = "Enable microphone";
        }
        this.say(error.message || "Microphone recording failed.");
      }
    } finally {
      this.opening = false;
    }
  }
  finish(discard = false) {
    if (discard && (this.opening || this.recording) && !this.disposed) this.say("Recording cancelled.");
    this.released = true;
    this.discard ||= discard;
    clearTimeout(this.timer);
    if (this.recorder?.state === "recording") this.recorder.stop();
  }
  releaseMicrophone() {
    this.microphoneGeneration += 1;
    this.stream?.getTracks().forEach((track) => track.stop());
    this.stream = void 0;
    this.microphoneReady = false;
    this.microphoneOff.hidden = true;
    if (!this.disposed) this.talk.textContent = "Enable microphone";
  }
  async submit(audio, context) {
    this.transcribing = true;
    this.talk.disabled = true;
    const abort = new AbortController();
    this.transcriptionAbort = abort;
    const id = crypto.randomUUID();
    this.say("Transcribing\u2026");
    try {
      const result = await this.transport.transcribe(audio, id, abort.signal);
      if (this.disposed || abort.signal.aborted) return;
      await this.transport.send(result.text, "voice-" + id, context);
      this.say("Voice message sent.");
    } catch (error) {
      if (!this.disposed) this.say(error.message || "Voice request failed.");
    } finally {
      this.transcribing = false;
      if (!this.disposed) this.talk.disabled = false;
      this.transcriptionAbort = void 0;
      void this.play();
    }
  }
  messages(rows) {
    for (const message of rows) {
      if (this.seen.has(message.id)) continue;
      this.seen.add(message.id);
      if (this.replies.checked && message.seq > this.speakAfter && message.reply_to && message.actor.startsWith("agent:"))
        this.pending.push(message.id);
    }
    void this.play();
  }
  async play() {
    if (this.playing || this.opening || this.recording || this.transcribing || this.disposed || !this.replies.checked) return;
    this.playing = true;
    const playback = this.playback;
    try {
      while (this.pending.length && playback === this.playback && !this.disposed && this.replies.checked) {
        const message = this.pending.shift();
        const abort = new AbortController();
        this.audioAbort = abort;
        this.stop.disabled = false;
        this.say("Preparing spoken reply\u2026");
        let url;
        try {
          const result = await this.transport.speech(message, crypto.randomUUID(), abort.signal);
          if (abort.signal.aborted || playback !== this.playback || this.disposed) {
            if (result instanceof Response) await result.body?.cancel();
            break;
          }
          if (result instanceof Response && result.headers.get("Content-Type")?.split(";")[0] === "audio/pcm") {
            await this.pcm.play(result, abort.signal, () => this.say("Speaking."));
            continue;
          }
          const blob = result instanceof Response ? await result.blob() : result;
          if (abort.signal.aborted || playback !== this.playback || this.disposed) break;
          url = URL.createObjectURL(blob);
          const audio = new Audio(url);
          this.audio = audio;
          this.say("Speaking.");
          await new Promise((resolve, reject) => {
            this.finishAudio = resolve;
            audio.onended = () => resolve();
            audio.onerror = () => reject(new Error("Spoken audio could not be played."));
            void audio.play().catch(() => reject(new Error("Audio playback was blocked. Toggle Speak replies and try again.")));
          });
        } catch (error) {
          if (!abort.signal.aborted && !this.disposed) this.say(error.message);
        } finally {
          this.finishAudio = void 0;
          this.audio = void 0;
          if (url) URL.revokeObjectURL(url);
        }
      }
    } finally {
      this.playing = false;
      if (!this.disposed) this.stop.disabled = true;
      this.audioAbort = void 0;
    }
  }
  stopAudio() {
    this.playback += 1;
    this.pending = [];
    this.audioAbort?.abort();
    this.audio?.pause();
    this.finishAudio?.();
    this.pcm.stop();
    this.stop.disabled = true;
    if (!this.disposed) this.say("Audio stopped.");
  }
  dispose() {
    if (this.disposed) return;
    this.disposed = true;
    this.capture += 1;
    this.events.abort();
    this.microphoneSetupAbort?.abort();
    this.finish(true);
    this.releaseMicrophone();
    this.transcriptionAbort?.abort();
    this.stopAudio();
    this.microphoneOff.remove();
    this.pcm.dispose();
    this.talk.disabled = true;
    this.replies.disabled = true;
    this.status.hidden = false;
    this.status.textContent = "Voice session ended.";
  }
};
async function voiceJson(response) {
  const value = await response.json();
  if (!response.ok) throw new Error(value.error || "Voice session is unavailable.");
  return value;
}

// extension/microphone.ts
async function prepareMicrophone(signal) {
  signal.throwIfAborted();
  const permission = await navigator.permissions.query({ name: "microphone" });
  if (permission.state === "granted") return;
  if (permission.state === "denied") throw new Error(
    "Microphone access is blocked. Allow it in this extension's Chrome site settings, then try again."
  );
  await new Promise((resolve, reject) => {
    let windowId, finished = false;
    const request = crypto.randomUUID();
    const page = chrome.runtime.getURL("microphone.html");
    const close = () => {
      if (windowId !== void 0) void chrome.windows.remove(windowId).catch(() => {
      });
    };
    const finish = (error) => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      chrome.runtime.onMessage.removeListener(receive);
      chrome.windows.onRemoved.removeListener(removed);
      signal.removeEventListener("abort", cancelled);
      window.removeEventListener("pagehide", cancelled);
      close();
      if (error) reject(error);
      else resolve();
    };
    const receive = (message, sender, respond) => {
      if (message.kind !== "microphone_permission_result" || message.request_id !== request || sender.id !== chrome.runtime.id || sender.url?.split("#")[0] !== page) return;
      respond({ ok: true });
      finish(message.granted ? void 0 : new Error("Microphone access was denied or unavailable."));
    };
    const removed = (id) => {
      if (id === windowId) finish(new Error("Microphone setup was cancelled. Try enabling it again."));
    };
    const cancelled = () => finish(new Error("Microphone setup was cancelled."));
    const timer = setTimeout(() => finish(new Error("Microphone setup timed out. Try again.")), 12e4);
    chrome.runtime.onMessage.addListener(receive);
    chrome.windows.onRemoved.addListener(removed);
    signal.addEventListener("abort", cancelled, { once: true });
    window.addEventListener("pagehide", cancelled, { once: true });
    if (signal.aborted) {
      cancelled();
      return;
    }
    void chrome.windows.create({
      url: page + "#request=" + request,
      type: "popup",
      width: 420,
      height: 350,
      focused: true
    }).then((popup) => {
      windowId = popup.id;
      if (finished) close();
    }, () => finish(new Error("Chrome could not open microphone permissions. Try again.")));
  });
}

// extension/panel.ts
var activeRunId;
var $ = (id) => document.getElementById(id);
var after = 0;
var sessionId = null;
var voice;
var voiceGeneration = 0;
var refreshing = false;
var refreshAgain = false;
var voicePanel = $("voice-panel");
async function call(message) {
  const result = await chrome.runtime.sendMessage(message);
  if (!result.ok) {
    const error = new Error(result.error);
    error.status = result.status;
    throw error;
  }
  return result;
}
function stopVoice() {
  voiceGeneration += 1;
  voice?.dispose();
  voice = void 0;
}
function failure(error) {
  if (error.status === 401 || error.status === 410) stopVoice();
  $("error").textContent = error.message;
}
function startVoice() {
  if (voice || !sessionId || !voicePanel.open || document.hidden) return;
  const owner = sessionId, generation = ++voiceGeneration;
  let credentials;
  const current = () => {
    if (owner !== sessionId || generation !== voiceGeneration) throw new Error("Voice session ended.");
  };
  async function request(action, body, options = {}) {
    current();
    const grant = await (credentials ??= call({ kind: "voice", browser_session_id: owner }));
    current();
    if (grant.session_id !== owner) throw new Error("The sharing session changed. Reopen voice controls.");
    const response = await fetch(grant.base + "/_browser/guest/voice/" + action, {
      credentials: "omit",
      redirect: "error",
      ...options,
      method: options.method ?? (body ? "POST" : "GET"),
      headers: {
        "Authorization": "Bearer " + grant.voice_token,
        ...body ? { "Content-Type": "application/json" } : {},
        ...options.headers
      },
      body: body ? JSON.stringify(body) : options.body
    });
    current();
    if (response.status === 401 || response.status === 410) {
      stopVoice();
      throw new Error("Voice session ended.");
    }
    return response;
  }
  const root = $("voice-controls");
  const talk = root.querySelector("[data-voice-talk]");
  talk.disabled = true;
  talk.textContent = "Enable microphone";
  talk.setAttribute("aria-pressed", "false");
  root.querySelector("[data-voice-replies]").disabled = true;
  root.querySelector("[data-voice-stop]").disabled = true;
  root.querySelector("[data-voice-status]").textContent = "Loading voice options\u2026";
  voice = new VoiceControls(root, {
    prepareMicrophone,
    info: async () => voiceJson(await request("info")),
    transcribe: async (audio, id, signal) => voiceJson(await request("transcribe", void 0, {
      method: "POST",
      body: audio,
      signal,
      headers: { "Content-Type": audio.type, "X-Voice-Request-ID": id }
    })),
    speech: async (message, id, signal) => {
      const response = await request("speech", { message_id: message, request_id: id, stream: typeof AudioContext !== "undefined" }, { signal });
      if (!response.ok) {
        await voiceJson(response);
        throw new Error("Speech unavailable.");
      }
      return response;
    },
    send: async (text, id) => {
      await voiceJson(await request("message", { request_id: id, body: text }));
      await refresh();
    }
  });
}
async function refresh() {
  if (refreshing) {
    refreshAgain = true;
    return;
  }
  refreshing = true;
  try {
    const result = await call({ kind: "state", after, browser_session_id: sessionId });
    $("pairing").hidden = !!result.session;
    $("session").hidden = !result.session;
    const next = result.session?.id ?? null;
    if (next !== sessionId) {
      stopVoice();
      sessionId = next;
      after = 0;
      $("messages").replaceChildren();
      $("voice-controls").querySelector("[data-voice-replies]").checked = false;
    }
    if (!result.session) return;
    activeRunId = result.session.active_run?.id;
    $("run-progress").hidden = !activeRunId;
    $("stop-run").hidden = !activeRunId;
    $("run-progress").textContent = "Truman is working \xB7 " + (result.session.active_run?.step_count ?? 0) + " steps";
    $("title").textContent = result.session.title;
    $("shared-origin").textContent = "Sharing " + (result.session.current_url ? new URL(result.session.current_url).origin : "the selected tab");
    $("status").textContent = !result.connected ? "Disconnected \u2014 agent control is paused" : result.granted && result.session.controller?.startsWith("agent:") ? "Truman may interact with this tab" : "Observe only \u2014 you control this tab";
    $("compatibility").hidden = result.mode !== "compatibility";
    if (result.mode === "helper") $("status").textContent += " \xB7 Local helper";
    $("compatibility").textContent = "Compatibility mode keeps your other extensions active. Native browser dialogs and pages requiring trusted input need normal mode.";
    const ended = ["closing", "closed", "expired", "failed", "cleanup_failed"].includes(result.session.state);
    if (ended) stopVoice();
    else startVoice();
    for (const message of result.messages ?? []) {
      const item = document.createElement("p");
      item.textContent = (message.actor.startsWith("agent:") ? "Truman: " : "You: ") + message.body;
      if (!message.actor.startsWith("agent:")) item.dataset.messageId = message.id;
      $("messages").append(item);
      after = Math.max(after, message.seq);
    }
    messageDelivery(
      $("messages"),
      [...result.messages ?? [], ...result.message_updates ?? []],
      (id) => void call({ kind: "retry-message", message_id: id, request_id: crypto.randomUUID() }).then(refresh).catch(failure)
    );
    voice?.messages(result.messages ?? []);
  } finally {
    refreshing = false;
    if (refreshAgain) {
      refreshAgain = false;
      void refresh().catch(failure);
    }
  }
}
$("pair").addEventListener("click", async () => {
  try {
    $("error").textContent = "";
    const invitation = $("invitation").value;
    const url = new URL(invitation);
    const mode = $("connection-mode").value;
    const granted = await chrome.permissions.request({
      origins: [url.origin + "/*"],
      ...mode === "helper" ? { permissions: ["nativeMessaging"] } : {}
    });
    if (!granted) throw new Error("Connection permission was not granted");
    await call({ kind: "pair", invitation, mode });
    await refresh();
  } catch (error) {
    failure(error);
  }
});
for (const [button, action] of [["grant", "grant"], ["pause", "pause"]])
  $(button).addEventListener("click", () => void call({ kind: "control", action }).then(refresh).catch(failure));
voicePanel.addEventListener("toggle", () => {
  if (voicePanel.open) startVoice();
  else stopVoice();
});
$("origin").addEventListener("click", () => void call({ kind: "origin" }).then(refresh).catch(failure));
$("disconnect").addEventListener("click", () => {
  stopVoice();
  void call({ kind: "disconnect" }).then(refresh).catch(failure);
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "session" && "connection" in changes) {
    stopVoice();
    void refresh().catch(failure);
  }
});
enterToSend($("body"), $("chat"));
$("chat").addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!$("body").value.trim()) return;
  try {
    const body = $("body");
    await call({ kind: "message", body: body.value });
    body.value = "";
    await refresh();
  } catch (error) {
    failure(error);
  }
});
document.addEventListener("visibilitychange", () => {
  if (document.hidden) stopVoice();
  else void refresh().catch(failure);
});
window.addEventListener("pagehide", stopVoice, { once: true });
setInterval(() => void refresh().catch(failure), 2e3);
void refresh().catch(failure);
$("extension-id").value = chrome.runtime.id;
$("invitation").addEventListener("input", () => {
  const link = $("helper-download");
  link.hidden = true;
  $("helper-link-hint").hidden = false;
  try {
    const url = new URL($("invitation").value);
    if (url.protocol !== "https:" && !["localhost", "127.0.0.1"].includes(url.hostname)) return;
    if (url.pathname !== "/_browser/guest/join") return;
    link.href = url.origin + "/_browser/helper";
    link.hidden = false;
    $("helper-link-hint").hidden = true;
  } catch {
  }
});
$("stop-run").addEventListener("click", () => {
  if (activeRunId) void call({ kind: "cancel-run" }).then(refresh).catch(failure);
});
